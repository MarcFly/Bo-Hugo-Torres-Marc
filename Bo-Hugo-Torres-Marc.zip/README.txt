# Bo-Hugo-Torres-Marc
Physics 2 Practical - Pinball Assignment

https://www.classicgame.com/game/Metal+Pinball

Controls:
Hold SpaceBar for some time and release to shoot the pinball.
Press Left to use the flippers situated on the left side of the scree.
Press Right to use the flippers situated on the right side of the screen.

Press F1 to show debug collisions.

Each bumper you bounce off, gives you 50 points.
Score and balls left are shown in the screen title.
Good Luck!